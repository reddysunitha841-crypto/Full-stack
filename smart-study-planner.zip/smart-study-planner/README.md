# Smart Study Planner

A beginner-friendly React (Vite) app to manage subjects, study tasks, a daily schedule, exam countdowns and progress. Data is saved in browser LocalStorage (no backend).

## Run
```
npm install
npm run dev
```
Open the link shown in the terminal (usually http://localhost:5173).
