import { useState } from 'react'
import { makeId, todayStr, daysUntil, formatDate } from '../utils/helpers'

const emptyForm = { name: '', subjectId: '', date: todayStr() }

export default function Exams({ subjects, exams, setExams }) {
  const [form, setForm] = useState(emptyForm)
  const [editingId, setEditingId] = useState(null)
  const [errors, setErrors] = useState({})

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value })

  const handleSubmit = (e) => {
    e.preventDefault()
    const err = {}
    if (!form.name.trim()) err.name = 'Exam name is required.'
    if (!form.subjectId) err.subjectId = 'Please select a subject.'
    if (!form.date) err.date = 'Please choose the exam date.'
    setErrors(err)
    if (Object.keys(err).length > 0) return

    const cleaned = { name: form.name.trim(), subjectId: form.subjectId, date: form.date }

    if (editingId) {
      setExams(exams.map((x) => (x.id === editingId ? { ...x, ...cleaned } : x)))
    } else {
      setExams([...exams, { id: makeId(), ...cleaned }])
    }
    setForm(emptyForm)
    setEditingId(null)
  }

  const handleEdit = (exam) => {
    setEditingId(exam.id)
    setForm({ name: exam.name, subjectId: exam.subjectId, date: exam.date })
    setErrors({})
  }

  const handleCancel = () => {
    setEditingId(null)
    setForm(emptyForm)
    setErrors({})
  }

  const handleDelete = (exam) => {
    if (!window.confirm(`Delete exam "${exam.name}"?`)) return
    setExams(exams.filter((x) => x.id !== exam.id))
    if (editingId === exam.id) handleCancel()
  }

  const subjectName = (id) => subjects.find((s) => s.id === id)?.name || 'Unknown'
  const sorted = [...exams].sort((a, b) => a.date.localeCompare(b.date))

  const countdownText = (dateStr) => {
    const d = daysUntil(dateStr)
    if (d < 0) return 'This exam date has passed'
    if (d === 0) return 'Exam is today!'
    return `${d} day${d === 1 ? '' : 's'} remaining`
  }

  return (
    <div>
      <h1>Exam Countdown</h1>

      {subjects.length === 0 ? (
        <p className="empty">Please add a subject first (Subjects page) before adding exams.</p>
      ) : (
        <form className="card form" onSubmit={handleSubmit}>
          <h3>{editingId ? 'Edit Exam' : 'Add Exam'}</h3>

          <div className="field">
            <label htmlFor="name">Exam Name</label>
            <input id="name" name="name" value={form.name} onChange={handleChange}
              placeholder="e.g. Mid-Semester Exam" />
            {errors.name && <p className="error">{errors.name}</p>}
          </div>

          <div className="field">
            <label htmlFor="subjectId">Subject</label>
            <select id="subjectId" name="subjectId" value={form.subjectId} onChange={handleChange}>
              <option value="">-- Select subject --</option>
              {subjects.map((s) => (
                <option key={s.id} value={s.id}>{s.name}</option>
              ))}
            </select>
            {errors.subjectId && <p className="error">{errors.subjectId}</p>}
          </div>

          <div className="field">
            <label htmlFor="date">Exam Date</label>
            <input id="date" type="date" name="date" value={form.date} onChange={handleChange} />
            {errors.date && <p className="error">{errors.date}</p>}
          </div>

          <div className="actions">
            <button className="btn primary" type="submit">
              {editingId ? 'Update Exam' : 'Add Exam'}
            </button>
            {editingId && (
              <button className="btn" type="button" onClick={handleCancel}>Cancel</button>
            )}
          </div>
        </form>
      )}

      {sorted.length === 0 ? (
        <p className="empty">No exams added yet.</p>
      ) : (
        <div className="grid cards">
          {sorted.map((x) => {
            const passed = daysUntil(x.date) < 0
            return (
              <div className="card" key={x.id}>
                <h3>{x.name}</h3>
                <p className="muted">{subjectName(x.subjectId)} • {formatDate(x.date)}</p>
                <p className={passed ? 'countdown passed' : 'countdown'}>{countdownText(x.date)}</p>
                <div className="actions">
                  <button className="btn" onClick={() => handleEdit(x)}>Edit</button>
                  <button className="btn danger" onClick={() => handleDelete(x)}>Delete</button>
                </div>
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}
