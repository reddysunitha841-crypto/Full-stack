import { useState } from 'react'
import { todayStr, formatDate, formatMinutes } from '../utils/helpers'

export default function Schedule({ subjects, tasks, setTasks }) {
  const [date, setDate] = useState(todayStr())

  const dayTasks = tasks.filter((t) => t.date === date)
  const totalMinutes = dayTasks.reduce((sum, t) => sum + t.duration, 0)
  const subjectName = (id) => subjects.find((s) => s.id === id)?.name || 'Unknown'

  const toggleComplete = (id) =>
    setTasks(tasks.map((t) => (t.id === id ? { ...t, completed: !t.completed } : t)))

  return (
    <div>
      <h1>Study Schedule</h1>

      <div className="card form">
        <div className="field">
          <label htmlFor="sdate">Select Date</label>
          <input id="sdate" type="date" value={date} onChange={(e) => setDate(e.target.value || todayStr())} />
        </div>
        <button className="btn" onClick={() => setDate(todayStr())}>Jump to Today</button>
      </div>

      <h3>
        {formatDate(date)} — {dayTasks.length} task{dayTasks.length === 1 ? '' : 's'}
        {dayTasks.length > 0 && ` • ${formatMinutes(totalMinutes)} planned`}
      </h3>

      {dayTasks.length === 0 ? (
        <p className="empty">No tasks scheduled for this date.</p>
      ) : (
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Task</th>
                <th>Subject</th>
                <th>Date</th>
                <th>Duration</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {dayTasks.map((t) => (
                <tr key={t.id}>
                  <td className={t.completed ? 'done' : ''}>{t.title}</td>
                  <td>{subjectName(t.subjectId)}</td>
                  <td>{formatDate(t.date)}</td>
                  <td>{t.duration} min</td>
                  <td>
                    <span className={t.completed ? 'badge low' : 'badge medium'}>
                      {t.completed ? 'Completed' : 'Pending'}
                    </span>
                  </td>
                  <td>
                    <button className="btn success" onClick={() => toggleComplete(t.id)}>
                      {t.completed ? 'Undo' : 'Complete'}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
