import StatCard from '../components/StatCard'
import ProgressBar from '../components/ProgressBar'
import { percent, formatMinutes } from '../utils/helpers'

export default function Progress({ tasks }) {
  const completed = tasks.filter((t) => t.completed).length
  const pending = tasks.length - completed
  const overall = percent(completed, tasks.length)
  const totalMinutes = tasks.reduce((sum, t) => sum + t.duration, 0)

  return (
    <div>
      <h1>Progress Tracker</h1>

      <div className="grid stats">
        <StatCard label="Tasks Completed" value={completed} color="green" />
        <StatCard label="Tasks Pending" value={pending} color="orange" />
        <StatCard label="Completion" value={`${overall}%`} color="purple" />
        <StatCard label="Planned Study Time" value={formatMinutes(totalMinutes)} color="blue" />
      </div>

      <div className="card">
        <h3>Overall Task Completion</h3>
        <ProgressBar percent={overall} />
        <p className="muted">
          {tasks.length === 0
            ? 'Add some study tasks to start tracking your progress.'
            : `${completed} of ${tasks.length} tasks completed`}
        </p>
      </div>
    </div>
  )
}
