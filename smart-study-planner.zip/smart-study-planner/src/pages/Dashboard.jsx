import StatCard from '../components/StatCard'
import ProgressBar from '../components/ProgressBar'
import { todayStr, daysUntil, percent, formatDate } from '../utils/helpers'

export default function Dashboard({ subjects, tasks, exams }) {
  const today = todayStr()
  const completed = tasks.filter((t) => t.completed).length
  const pending = tasks.length - completed

  const todayTasks = tasks.filter((t) => t.date === today)
  const todayDone = todayTasks.filter((t) => t.completed).length
  const dailyPercent = percent(todayDone, todayTasks.length)

  const upcomingExams = exams
    .filter((e) => daysUntil(e.date) >= 0)
    .sort((a, b) => a.date.localeCompare(b.date))
    .slice(0, 5)

  const subjectName = (id) => subjects.find((s) => s.id === id)?.name || 'Unknown'

  return (
    <div>
      <h1>Welcome to Smart Study Planner</h1>
      <p className="muted">Here is a quick overview of your studies.</p>

      <div className="grid stats">
        <StatCard label="Total Subjects" value={subjects.length} color="blue" />
        <StatCard label="Total Study Tasks" value={tasks.length} color="purple" />
        <StatCard label="Completed Tasks" value={completed} color="green" />
        <StatCard label="Pending Tasks" value={pending} color="orange" />
      </div>

      <div className="card">
        <h3>Daily Study Progress</h3>
        <ProgressBar percent={dailyPercent} />
        <p className="muted">
          {todayTasks.length === 0
            ? 'No tasks planned for today.'
            : `${todayDone} of ${todayTasks.length} tasks done today`}
        </p>
      </div>

      <div className="grid two">
        <div className="card">
          <h3>Today's Study Schedule</h3>
          {todayTasks.length === 0 ? (
            <p className="empty">Nothing scheduled for today.</p>
          ) : (
            <ul className="list">
              {todayTasks.map((t) => (
                <li key={t.id}>
                  <span className={t.completed ? 'done' : ''}>
                    {t.title} <small>({subjectName(t.subjectId)})</small>
                  </span>
                  <small>{t.duration} min</small>
                </li>
              ))}
            </ul>
          )}
        </div>

        <div className="card">
          <h3>Upcoming Exams</h3>
          {upcomingExams.length === 0 ? (
            <p className="empty">No upcoming exams.</p>
          ) : (
            <ul className="list">
              {upcomingExams.map((e) => {
                const d = daysUntil(e.date)
                return (
                  <li key={e.id}>
                    <span>
                      {e.name} <small>({subjectName(e.subjectId)})</small>
                    </span>
                    <small>
                      {formatDate(e.date)} •{' '}
                      {d === 0 ? 'Today!' : `${d} day${d === 1 ? '' : 's'} left`}
                    </small>
                  </li>
                )
              })}
            </ul>
          )}
        </div>
      </div>
    </div>
  )
}
