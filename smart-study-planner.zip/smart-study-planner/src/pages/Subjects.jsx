import { useState } from 'react'
import { makeId } from '../utils/helpers'

const emptyForm = { name: '', priority: 'Medium' }

export default function Subjects({ subjects, setSubjects, tasks, setTasks, exams, setExams }) {
  const [form, setForm] = useState(emptyForm)
  const [editingId, setEditingId] = useState(null)
  const [error, setError] = useState('')

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value })

  const handleSubmit = (e) => {
    e.preventDefault()
    const name = form.name.trim()

    if (!name) return setError('Subject name is required.')
    const duplicate = subjects.some(
      (s) => s.name.toLowerCase() === name.toLowerCase() && s.id !== editingId
    )
    if (duplicate) return setError('This subject already exists.')

    if (editingId) {
      setSubjects(
        subjects.map((s) =>
          s.id === editingId ? { ...s, name, priority: form.priority } : s
        )
      )
    } else {
      setSubjects([...subjects, { id: makeId(), name, priority: form.priority }])
    }
    setForm(emptyForm)
    setEditingId(null)
    setError('')
  }

  const handleEdit = (subject) => {
    setEditingId(subject.id)
    setForm({ name: subject.name, priority: subject.priority })
    setError('')
  }

  const handleCancel = () => {
    setEditingId(null)
    setForm(emptyForm)
    setError('')
  }

  const handleDelete = (subject) => {
    const ok = window.confirm(
      `Delete "${subject.name}"? Its tasks and exams will also be deleted.`
    )
    if (!ok) return
    setSubjects(subjects.filter((s) => s.id !== subject.id))
    setTasks(tasks.filter((t) => t.subjectId !== subject.id))
    setExams(exams.filter((x) => x.subjectId !== subject.id))
    if (editingId === subject.id) handleCancel()
  }

  return (
    <div>
      <h1>Subjects</h1>

      <form className="card form" onSubmit={handleSubmit}>
        <h3>{editingId ? 'Edit Subject' : 'Add Subject'}</h3>
        <div className="field">
          <label htmlFor="name">Subject Name</label>
          <input
            id="name"
            name="name"
            value={form.name}
            onChange={handleChange}
            placeholder="e.g. Data Structures"
          />
        </div>
        <div className="field">
          <label htmlFor="priority">Priority</label>
          <select id="priority" name="priority" value={form.priority} onChange={handleChange}>
            <option>High</option>
            <option>Medium</option>
            <option>Low</option>
          </select>
        </div>
        {error && <p className="error">{error}</p>}
        <div className="actions">
          <button className="btn primary" type="submit">
            {editingId ? 'Update Subject' : 'Add Subject'}
          </button>
          {editingId && (
            <button className="btn" type="button" onClick={handleCancel}>
              Cancel
            </button>
          )}
        </div>
      </form>

      {subjects.length === 0 ? (
        <p className="empty">No subjects yet. Add your first subject above.</p>
      ) : (
        <div className="grid cards">
          {subjects.map((s) => (
            <div className="card" key={s.id}>
              <h3>{s.name}</h3>
              <span className={`badge ${s.priority.toLowerCase()}`}>{s.priority} priority</span>
              <div className="actions">
                <button className="btn" onClick={() => handleEdit(s)}>Edit</button>
                <button className="btn danger" onClick={() => handleDelete(s)}>Delete</button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
