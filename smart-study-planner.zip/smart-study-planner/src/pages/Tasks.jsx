import { useState } from 'react'
import { makeId, todayStr, formatDate } from '../utils/helpers'

const emptyForm = {
  title: '',
  subjectId: '',
  date: todayStr(),
  duration: '',
  priority: 'Medium',
}

export default function Tasks({ subjects, tasks, setTasks }) {
  const [form, setForm] = useState(emptyForm)
  const [editingId, setEditingId] = useState(null)
  const [errors, setErrors] = useState({})
  const [filter, setFilter] = useState('All')

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value })

  const validate = () => {
    const err = {}
    if (!form.title.trim()) err.title = 'Task title is required.'
    if (!form.subjectId) err.subjectId = 'Please select a subject.'
    if (!form.date) err.date = 'Please choose a date.'
    const mins = Number(form.duration)
    if (!form.duration || !Number.isInteger(mins) || mins <= 0)
      err.duration = 'Enter a whole number of minutes greater than 0.'
    return err
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    const err = validate()
    setErrors(err)
    if (Object.keys(err).length > 0) return

    const cleaned = {
      title: form.title.trim(),
      subjectId: form.subjectId,
      date: form.date,
      duration: Number(form.duration),
      priority: form.priority,
    }

    if (editingId) {
      setTasks(tasks.map((t) => (t.id === editingId ? { ...t, ...cleaned } : t)))
    } else {
      setTasks([...tasks, { id: makeId(), ...cleaned, completed: false }])
    }
    setForm(emptyForm)
    setEditingId(null)
  }

  const handleEdit = (task) => {
    setEditingId(task.id)
    setForm({
      title: task.title,
      subjectId: task.subjectId,
      date: task.date,
      duration: String(task.duration),
      priority: task.priority,
    })
    setErrors({})
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  const handleCancel = () => {
    setEditingId(null)
    setForm(emptyForm)
    setErrors({})
  }

  const toggleComplete = (id) =>
    setTasks(tasks.map((t) => (t.id === id ? { ...t, completed: !t.completed } : t)))

  const handleDelete = (task) => {
    if (!window.confirm(`Delete task "${task.title}"?`)) return
    setTasks(tasks.filter((t) => t.id !== task.id))
    if (editingId === task.id) handleCancel()
  }

  const subjectName = (id) => subjects.find((s) => s.id === id)?.name || 'Unknown'

  const visibleTasks = tasks
    .filter((t) =>
      filter === 'All' ? true : filter === 'Completed' ? t.completed : !t.completed
    )
    .sort((a, b) => a.date.localeCompare(b.date))

  return (
    <div>
      <h1>Study Tasks</h1>

      {subjects.length === 0 ? (
        <p className="empty">Please add a subject first (Subjects page) before creating tasks.</p>
      ) : (
        <form className="card form" onSubmit={handleSubmit}>
          <h3>{editingId ? 'Edit Task' : 'Add Task'}</h3>

          <div className="field">
            <label htmlFor="title">Task Title</label>
            <input id="title" name="title" value={form.title} onChange={handleChange}
              placeholder="e.g. Revise Linked Lists" />
            {errors.title && <p className="error">{errors.title}</p>}
          </div>

          <div className="field">
            <label htmlFor="subjectId">Subject</label>
            <select id="subjectId" name="subjectId" value={form.subjectId} onChange={handleChange}>
              <option value="">-- Select subject --</option>
              {subjects.map((s) => (
                <option key={s.id} value={s.id}>{s.name}</option>
              ))}
            </select>
            {errors.subjectId && <p className="error">{errors.subjectId}</p>}
          </div>

          <div className="field">
            <label htmlFor="date">Study Date</label>
            <input id="date" type="date" name="date" value={form.date} onChange={handleChange} />
            {errors.date && <p className="error">{errors.date}</p>}
          </div>

          <div className="field">
            <label htmlFor="duration">Planned Duration (minutes)</label>
            <input id="duration" type="number" min="1" name="duration" value={form.duration}
              onChange={handleChange} placeholder="e.g. 45" />
            {errors.duration && <p className="error">{errors.duration}</p>}
          </div>

          <div className="field">
            <label htmlFor="priority">Priority</label>
            <select id="priority" name="priority" value={form.priority} onChange={handleChange}>
              <option>High</option>
              <option>Medium</option>
              <option>Low</option>
            </select>
          </div>

          <div className="actions">
            <button className="btn primary" type="submit">
              {editingId ? 'Update Task' : 'Add Task'}
            </button>
            {editingId && (
              <button className="btn" type="button" onClick={handleCancel}>Cancel</button>
            )}
          </div>
        </form>
      )}

      <div className="filters">
        {['All', 'Pending', 'Completed'].map((f) => (
          <button key={f} className={filter === f ? 'btn primary' : 'btn'} onClick={() => setFilter(f)}>
            {f}
          </button>
        ))}
      </div>

      {visibleTasks.length === 0 ? (
        <p className="empty">
          {tasks.length === 0
            ? 'No tasks yet. Add your first study task above.'
            : `No ${filter.toLowerCase()} tasks.`}
        </p>
      ) : (
        <div className="grid cards">
          {visibleTasks.map((t) => (
            <div className="card" key={t.id}>
              <h3 className={t.completed ? 'done' : ''}>{t.title}</h3>
              <p className="muted">
                {subjectName(t.subjectId)} • {formatDate(t.date)} • {t.duration} min
              </p>
              <span className={`badge ${t.priority.toLowerCase()}`}>{t.priority}</span>{' '}
              <span className={t.completed ? 'badge low' : 'badge medium'}>
                {t.completed ? 'Completed' : 'Pending'}
              </span>
              <div className="actions">
                <button className="btn success" onClick={() => toggleComplete(t.id)}>
                  {t.completed ? 'Mark Pending' : 'Complete'}
                </button>
                <button className="btn" onClick={() => handleEdit(t)}>Edit</button>
                <button className="btn danger" onClick={() => handleDelete(t)}>Delete</button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
