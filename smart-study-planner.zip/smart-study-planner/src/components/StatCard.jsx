export default function StatCard({ label, value, color = 'blue' }) {
  return (
    <div className={`card stat ${color}`}>
      <p className="stat-label">{label}</p>
      <p className="stat-value">{value}</p>
    </div>
  )
}
