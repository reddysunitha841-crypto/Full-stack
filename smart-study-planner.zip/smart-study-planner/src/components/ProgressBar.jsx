export default function ProgressBar({ percent }) {
  return (
    <div className="progress-track" aria-label={`Progress ${percent}%`}>
      <div className="progress-fill" style={{ width: `${percent}%` }}>
        {percent > 8 ? `${percent}%` : ''}
      </div>
    </div>
  )
}
