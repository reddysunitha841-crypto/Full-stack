const links = [
  ['dashboard', '🏠 Dashboard'],
  ['subjects', '📚 Subjects'],
  ['tasks', '✅ Study Tasks'],
  ['schedule', '🗓️ Schedule'],
  ['exams', '⏳ Exams'],
  ['progress', '📈 Progress'],
]

export default function Sidebar({ page, setPage }) {
  return (
    <aside className="sidebar">
      <h2 className="logo">Smart Study Planner</h2>
      <nav>
        {links.map(([key, label]) => (
          <button
            key={key}
            className={page === key ? 'nav-btn active' : 'nav-btn'}
            onClick={() => setPage(key)}
          >
            {label}
          </button>
        ))}
      </nav>
    </aside>
  )
}
