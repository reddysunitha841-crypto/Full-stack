// Unique ID for subjects, tasks and exams
export const makeId = () =>
  Date.now().toString(36) + Math.random().toString(36).slice(2, 8)

// Today's date as YYYY-MM-DD (local time, matches <input type="date">)
export const todayStr = () => {
  const d = new Date()
  const m = String(d.getMonth() + 1).padStart(2, '0')
  const day = String(d.getDate()).padStart(2, '0')
  return `${d.getFullYear()}-${m}-${day}`
}

// Number of days from today until the given date (negative = passed)
export const daysUntil = (dateStr) => {
  const [y, m, d] = dateStr.split('-').map(Number)
  const target = new Date(y, m - 1, d)
  const now = new Date()
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate())
  return Math.round((target - today) / 86400000)
}

// Completion percentage that never gives NaN
export const percent = (done, total) =>
  total === 0 ? 0 : Math.round((done / total) * 100)

export const formatDate = (dateStr) => {
  const [y, m, d] = dateStr.split('-').map(Number)
  return new Date(y, m - 1, d).toLocaleDateString(undefined, {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  })
}

// 135 -> "2h 15m"
export const formatMinutes = (mins) => {
  const h = Math.floor(mins / 60)
  const m = mins % 60
  if (h === 0) return `${m}m`
  return m === 0 ? `${h}h` : `${h}h ${m}m`
}
