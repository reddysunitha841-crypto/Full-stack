import { useState } from 'react'
import useLocalStorage from './hooks/useLocalStorage'
import Sidebar from './components/Sidebar'
import Dashboard from './pages/Dashboard'
import Subjects from './pages/Subjects'
import Tasks from './pages/Tasks'
import Schedule from './pages/Schedule'
import Exams from './pages/Exams'
import Progress from './pages/Progress'

export default function App() {
  const [page, setPage] = useState('dashboard')
  const [subjects, setSubjects] = useLocalStorage('ssp_subjects', [])
  const [tasks, setTasks] = useLocalStorage('ssp_tasks', [])
  const [exams, setExams] = useLocalStorage('ssp_exams', [])

  const data = { subjects, setSubjects, tasks, setTasks, exams, setExams }

  const renderPage = () => {
    switch (page) {
      case 'subjects':
        return <Subjects {...data} />
      case 'tasks':
        return <Tasks {...data} />
      case 'schedule':
        return <Schedule {...data} />
      case 'exams':
        return <Exams {...data} />
      case 'progress':
        return <Progress {...data} />
      default:
        return <Dashboard {...data} />
    }
  }

  return (
    <div className="app">
      <Sidebar page={page} setPage={setPage} />
      <main className="content">{renderPage()}</main>
    </div>
  )
}
